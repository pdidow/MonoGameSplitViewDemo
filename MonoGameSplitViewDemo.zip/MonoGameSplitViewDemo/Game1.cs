﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MonoGameSplitViewDemo
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private SpriteFont _infoFont;
        private Texture2D _borderTexture;  
        // Viewport rectangles
        private Rectangle _gameViewport;
        private Rectangle _infoViewport;
        private Texture2D _gameTexture;
        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // Set window size
            _graphics.PreferredBackBufferWidth = 1280;  // For example
            _graphics.PreferredBackBufferHeight = 720;
            _graphics.ApplyChanges();

            // Create viewports - game takes 75% of width, info panel 25%
            _gameViewport = new Rectangle(
                0, 0,
                (int)(_graphics.PreferredBackBufferWidth * 0.75f),
                _graphics.PreferredBackBufferHeight
            );

            _infoViewport = new Rectangle(
                _gameViewport.Width, 0,
                _graphics.PreferredBackBufferWidth - _gameViewport.Width,
                _graphics.PreferredBackBufferHeight
            );

            base.Initialize();
        }

        protected override void LoadContent()
        {
           
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            _infoFont = Content.Load<SpriteFont>("Inkfree_20");
            _gameTexture = Content.Load<Texture2D>("GameTexture");
            _borderTexture = new Texture2D(GraphicsDevice, 1, 1);
            _borderTexture.SetData(new[] { Color.Purple }); // Set the texture color directly


        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // Draw main game viewport
            _spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend);
            GraphicsDevice.Viewport = new Viewport(_gameViewport);
            DrawGameScene();
            _spriteBatch.End();

            // Draw info panel viewport
            _spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp, DepthStencilState.None,RasterizerState.CullCounterClockwise);
            GraphicsDevice.Viewport = new Viewport(_infoViewport);
            DrawInfoPanel();
            _spriteBatch.End();

            base.Draw(gameTime);
        }


        private void DrawGameScene()
        {
            //Draw the demo texture
            _spriteBatch.Draw(_gameTexture, new Rectangle(_gameViewport.Width/2-_gameTexture.Width,_gameViewport.Height/2-_gameTexture.Height,_gameTexture.Width,_gameTexture.Height), Color.White);
        }
        // Method to draw the border
        private void DrawBorder(Rectangle rectangle, int thickness, Color color)
        {
            
            // Draw borders relative to the viewport's local space
            _spriteBatch.Draw(_borderTexture, new Rectangle(rectangle.X, rectangle.Y, rectangle.Width, thickness),color); // Top
            _spriteBatch.Draw(_borderTexture, new Rectangle(rectangle.X, rectangle.Y + rectangle.Height - thickness, rectangle.Width, thickness), color); // Bottom
            _spriteBatch.Draw(_borderTexture, new Rectangle(rectangle.X, rectangle.Y, thickness, rectangle.Height), color); // Left
            _spriteBatch.Draw(_borderTexture, new Rectangle(rectangle.X + rectangle.Width - thickness, rectangle.Y, thickness, rectangle.Height), color); // Right

           
        }

        private void DrawInfoPanel()
        {

            // Ensure the border is drawn relative to the viewport
            Rectangle localRectangle = new Rectangle(
                0, 0, // Local position within the viewport
                _infoViewport.Width, _infoViewport.Height
            );

            // Draw the border first
            DrawBorder(localRectangle, 10, Color.White);

            Vector2 textPosition = new Vector2(10, 10);
            float lineSpacing = 30;

            // Draw environmental information
            _spriteBatch.DrawString(_infoFont,
                $"Wind Speed: 22 mph",
                textPosition,
                Color.White);

            textPosition.Y += lineSpacing;
            _spriteBatch.DrawString(_infoFont,
                $"Wind Direction: NE ",
                textPosition,
                Color.White);

            textPosition.Y += lineSpacing;
            _spriteBatch.DrawString(_infoFont,
                $"Water Current: 22 units",
                textPosition,
                Color.White);

            
        }
    }
}
