﻿using var game = new MonoGameSplitViewDemo.Game1();
game.Run();
